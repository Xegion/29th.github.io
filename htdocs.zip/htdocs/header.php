<div id="header" class="d-none d-sm-none d-md-none d-lg-block d-xl-block">
	<div id="edge_compat_two">
		<img id="logo" src="assets/img/logo.png">
		<ul id="header_dropshadow">
			<li id="home_button_dropshadow"><a href="index">HOME</a></li>
			<li id="about_button_dropshadow"><a href="about">ABOUT</a></li>
			<li id="roster_button_dropshadow"><a href="http://personnel.29th.org/" target="_blank">ROSTER</a></li>
			<li id="forum_button_dropshadow"><a href="http://forums.29th.org/categories" target="_blank">FORUM</a></li>
			<li id="enlist_button_dropshadow"><a href="enlist">ENLIST</a></li>
			<li id="servers_button_dropshadow"><a href="servers">SERVERS</a></li>
			<li id="wiki_button_dropshadow"><a href="http://www.29th.org/wiki/index.php?title=Main_Page" target="_blank">WIKI</a></li>
			<li id="donate_button_dropshadow"><a href="donate">DONATE</a></li>
		</ul>
		<ul id="header_dropshadow_fix">
			<li id="home_button_dropshadow_fix"><a href="index">HOME</a></li>
			<li id="about_button_dropshadow_fix"><a href="about">ABOUT</a></li>
			<li id="roster_button_dropshadow_fix"><a href="http://personnel.29th.org/" target="_blank">ROSTER</a></li>
			<li id="forum_button_dropshadow_fix"><a href="http://forums.29th.org/categories" target="_blank">FORUM</a></li>
			<li id="enlist_button_dropshadow_fix"><a href="enlist">ENLIST</a></li>
			<li id="servers_button_dropshadow_fix"><a href="servers">SERVERS</a></li>
			<li id="wiki_button_dropshadow_fix"><a href="http://www.29th.org/wiki/index.php?title=Main_Page" target="_blank">WIKI</a></li>
			<li id="donate_button_dropshadow_fix"><a href="donate">DONATE</a></li>
		</ul>
		<ul>
			<li id="home_button"><a href="index">HOME</a></li>
			<li id="about_button"><a href="about">ABOUT</a></li>
			<li id="roster_button"><a href="http://personnel.29th.org/" target="_blank">ROSTER</a></li>
			<li id="forum_button"><a href="http://forums.29th.org/categories" target="_blank">FORUM</a></li>
			<li id="enlist_button"><a href="enlist">ENLIST</a></li>
			<li id="servers_button"><a href="servers">SERVERS</a></li>
			<li id="wiki_button"><a href="http://www.29th.org/wiki/index.php?title=Main_Page" target="_blank">WIKI</a></li>
			<li id="donate_button"><a href="donate">DONATE</a></li>
		</ul>
	</div>
	<div id="edge_compat">
		<img id="logo" src="assets/img/logo.png">
		<ul>
			<li id="home_button_four"><a href="index">HOME</a></li>
			<li id="about_button_four"><a href="about">ABOUT</a></li>
			<li id="roster_button_four"><a href="http://personnel.29th.org/" target="_blank">ROSTER</a></li>
			<li id="forum_button_four"><a href="http://forums.29th.org/categories" target="_blank">FORUM</a></li>
			<li id="enlist_button_four"><a href="enlist">ENLIST</a></li>
			<li id="servers_button_four"><a href="servers">SERVERS</a></li>
			<li id="wiki_button_four"><a href="http://www.29th.org/wiki/index.php?title=Main_Page" target="_blank">WIKI</a></li>
			<li id="donate_button_four"><a href="donate">DONATE</a></li>
		</ul>
	</div>
</div>
<span class="d-none d-sm-none d-md-none d-lg-block d-xl-block">
	<div id="header_two" class="animated slideInDown">
		<div id="edge_compat_three">
			<img id="logo" src="assets/img/logo.png">
			<ul id="header_dropshadow_fix_two">
				<li id="home_button_dropshadow_fix_two"><a href="index">HOME</a></li>
				<li id="about_button_dropshadow_fix_two"><a href="about">ABOUT</a></li>
				<li id="roster_button_dropshadow_fix_two"><a href="http://personnel.29th.org/" target="_blank">ROSTER</a></li>
				<li id="forum_button_dropshadow_fix_two"><a href="http://forums.29th.org/categories" target="_blank">FORUM</a></li>
				<li id="enlist_button_dropshadow_fix_two"><a href="enlist">ENLIST</a></li>
				<li id="servers_button_dropshadow_fix_two"><a href="servers">SERVERS</a></li>
				<li id="wiki_button_dropshadow_fix_two"><a href="http://www.29th.org/wiki/index.php?title=Main_Page" target="_blank">WIKI</a></li>
				<li id="donate_button_dropshadow_fix_two"><a href="donate">DONATE</a></li>
			</ul>
			<ul>
				<li id="home_button_two"><a href="index">HOME</a></li>
				<li id="about_button_two"><a href="about">ABOUT</a></li>
				<li id="roster_button_two"><a href="http://personnel.29th.org/" target="_blank">ROSTER</a></li>
				<li id="forum_button_two"><a href="http://forums.29th.org/categories" target="_blank">FORUM</a></li>
				<li id="enlist_button_two"><a href="enlist">ENLIST</a></li>
				<li id="servers_button_two"><a href="servers">SERVERS</a></li>
				<li id="wiki_button_two"><a href="http://www.29th.org/wiki/index.php?title=Main_Page" target="_blank">WIKI</a></li>
				<li id="donate_button_two"><a href="donate">DONATE</a></li>
			</ul>
		</div>
		<div id="edge_compat_four">
			<img id="logo" src="assets/img/logo.png">
			<ul>
				<li id="home_button_five"><a href="index">HOME</a></li>
				<li id="about_button_five"><a href="about">ABOUT</a></li>
				<li id="roster_button_five"><a href="http://personnel.29th.org/" target="_blank">ROSTER</a></li>
				<li id="forum_button_five"><a href="http://forums.29th.org/categories" target="_blank">FORUM</a></li>
				<li id="enlist_button_five"><a href="enlist">ENLIST</a></li>
				<li id="servers_button_five"><a href="servers">SERVERS</a></li>
				<li id="wiki_button_five"><a href="http://www.29th.org/wiki/index.php?title=Main_Page" target="_blank">WIKI</a></li>
				<li id="donate_button_five"><a href="donate">DONATE</a></li>
			</ul>
		</div>
	</div>
	<button onclick="scrollTopFunction()" id="TopBtn" title="Top" class="animated slideInRight">&#9650;</button>
</span>
<div id="social_media" class="d-none d-sm-none d-md-none d-lg-block d-xl-block">
	<a id="facebook_link" title="Facebook" href="https://www.facebook.com/29thinfantrydivision" target="_blank"><span class="fa fa-facebook"></span></a>
	<a id="twitter_link" title="Twitter" href="https://twitter.com/TwentyNinthID" target="_blank"><span class="fa fa-twitter"></span></a>
	<a id="youtube_link" title="Youtube" href="https://www.youtube.com/channel/UC5mY7PbvGEtfBxH08HHP9Bg" target="_blank"><span class="fa fa-youtube"></span></a>
	<a id="twitch_link" title="Twitch" href="https://www.twitch.tv/29thinfantrydivision" target="_blank"><span class="fa fa-twitch"></span></a>
	<a id="about_link" title="Information" onclick="document.getElementById('stats_info_popup').style.display = 'block'; document.getElementById('popup_blur').style.display = 'block';" target="_blank"><span class="fa fa-info"></span></a>
</div>
<?php
    $group = simplexml_load_string(file_get_contents('https://steamcommunity.com/groups/' . '29thid' . '/memberslistxml/?xml=1'));
?>
<span class="d-none d-sm-none d-md-none d-lg-block d-xl-block">
	<span id="popup_blur">
	</span>
	<div id="stats_info_popup" class="animated zoomIn">
		<p id="steam_group_members_title">Steam Group</p>
		<p id="steam_group_members"><?php echo $group->groupDetails->memberCount ?></p>
		<p id="personnel_title">Registered</p>
		<p id="personnel_count">20000+</p>
		<p id="about_popup_title"><b>Information</b></p>
		<p id="about_popup_text">The 29th Infantry Division is a realism unit spread throughout multiple games in multiple time periods. Each game is supported separately by different companies while serving under the same Battalion so that all games and soldiers function individually and as all whole.</p>
		<p id="about_popup_close" onclick="document.getElementById('stats_info_popup').style.display = 'none'; document.getElementById('popup_blur').style.display = 'none';">x</p>
	</div>
</span>
<div id="header_small" class="d-block d-sm-block d-md-block d-lg-none d-xl-none">
	<p id="menu" onclick="document.getElementById('mobile_dropdown').style.height = '350px'; document.getElementById('menu').style.display = 'none'; document.getElementById('menu_two').style.display = 'flex'">MENU</p>
	<p id="menu_two" onclick="document.getElementById('mobile_dropdown').style.height = '0vh'; document.getElementById('menu').style.display = 'flex'; document.getElementById('menu_two').style.display = 'none'">MENU</p>
	<div id="mobile_dropdown">
		<div id="mobile_text">
			<a id="mobile_dropdown_link" href="index"><p id="home_button_three">HOME</p></a>
			<a id="mobile_dropdown_link" href="about"><p id="about_button_three">ABOUT</p></a>
			<a id="mobile_dropdown_link" href="http://personnel.29th.org/"><p id="roster_button_three">ROSTER</p></a>
			<a id="mobile_dropdown_link" href="http://forums.29th.org/categories"><p id="forum_button_three">FORUM</p></a>
			<a id="mobile_dropdown_link" href="enlist"><p id="enlist_button_three">ENLIST</p></a>
			<a id="mobile_dropdown_link" href="servers"><p id="servers_button_three">SERVERS</p></a>
			<a id="mobile_dropdown_link" href="http://www.29th.org/wiki/index.php?title=Main_Page"><p id="wiki_button_three">WIKI</p></a>
			<a id="mobile_dropdown_link" href="donate"><p id="donate_button_three">DONATE</p></a>
		</div>
	</div>
</div>
<script>
	function isInView(elem){
		return $(elem).offset().top - $(window).scrollTop() < $(elem).height();
	}
	$(document).ready( function() {
	    $("#header_two").hide();
	    var topOfOthDiv = $("#home_top").offset().top;
	    $(window).scroll(function() {
	        if($(window).scrollTop() > topOfOthDiv) {
				document.getElementById("header_two").style.display = "block";
			} else {
				document.getElementById("header_two").style.display = "none";
	        }
	    });
	});
	$(document).ready( function() {
	    $("#header_two").hide();
	    var topOfOthDiv = $("#about_top").offset().top;
	    $(window).scroll(function() {
	        if($(window).scrollTop() > topOfOthDiv) {
				document.getElementById("header_two").style.display = "block";
			} else {
				document.getElementById("header_two").style.display = "none";
	        }
	    });
	});
	$(document).ready( function() {
	    $("#header_two").hide();
	    var topOfOthDiv = $("#enlist_top").offset().top;
	    $(window).scroll(function() {
	        if($(window).scrollTop() > topOfOthDiv) {
				document.getElementById("header_two").style.display = "block";
			} else {
				document.getElementById("header_two").style.display = "none";
	        }
	    });
	});
	$(document).ready( function() {
	    $("#header_two").hide();
	    var topOfOthDiv = $("#servers_top").offset().top;
	    $(window).scroll(function() {
	        if($(window).scrollTop() > topOfOthDiv) {
				document.getElementById("header_two").style.display = "block";
			} else {
				document.getElementById("header_two").style.display = "none";
	        }
	    });
	});
	$(document).ready( function() {
	    $("#header_two").hide();
	    var topOfOthDiv = $("#donate_top").offset().top;
	    $(window).scroll(function() {
	        if($(window).scrollTop() > topOfOthDiv) {
				document.getElementById("header_two").style.display = "block";
			} else {
				document.getElementById("header_two").style.display = "none";
	        }
	    });
	});
	$(document).ready( function() {
	    $("#header_two").hide();
	    var topOfOthDiv = $("#privacy_top").offset().top;
	    $(window).scroll(function() {
	        if($(window).scrollTop() > topOfOthDiv) {
				document.getElementById("header_two").style.display = "block";
			} else {
				document.getElementById("header_two").style.display = "none";
	        }
	    });
	});
	window.onscroll = function() {scrollFunction()};
	function scrollFunction() {
		if (document.body.scrollTop > 70 || document.documentElement.scrollTop > 70) {
			document.getElementById("TopBtn").style.display = "block";
		} else {
			document.getElementById("TopBtn").style.display = "none";
		}
	}
	function scrollTopFunction() {
		window.scrollTo({top: 0, behavior: 'smooth'});
	}
	$(window).scroll(function() {
		if($(window).scrollTop() + $(window).height() == $(document).height()) {
			buttonfix();
		} else {
			document.getElementById("TopBtn").style.marginBottom = "0";
		}
	});
	function onElementHeightChange(elm, callback){
	    var lastHeight = elm.clientHeight, newHeight;
	    (function run(){
	        newHeight = elm.clientHeight;
	        if( lastHeight != newHeight )
	            callback();
	        lastHeight = newHeight;

	        if( elm.onElementHeightChangeTimer )
	            clearTimeout(elm.onElementHeightChangeTimer);

	        elm.onElementHeightChangeTimer = setTimeout(run, 200);
	    })();
	}
	onElementHeightChange(document.body, function(){
		if($(window).scrollTop() + $(window).height() == $(document).height()) {
			buttonfix();
		} else {
			document.getElementById("TopBtn").style.marginBottom = "0";
		}
	});
	function buttonfix() {
		document.getElementById("TopBtn").style.marginBottom = "20vh";
	}
	if (document.documentMode || /Edge/.test(navigator.userAgent)) {
		document.getElementById("edge_compat_two").style.display = "none";
		document.getElementById("edge_compat").style.display = "block";
		document.getElementById("edge_compat_three").style.display = "none";
		document.getElementById("edge_compat_four").style.display = "block";
	}
	if (navigator.userAgent.toLowerCase().indexOf('firefox') > -1) {
		document.getElementById("edge_compat_two").style.display = "none";
		document.getElementById("edge_compat").style.display = "block";
		document.getElementById("edge_compat_three").style.display = "none";
		document.getElementById("edge_compat_four").style.display = "block";
	}
</script>