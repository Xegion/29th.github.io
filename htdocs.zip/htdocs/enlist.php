<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<title>Enlist - 29th Infantry Division</title>
		<meta name="description" content="The 29th Infantry Division is a realism unit spread throughout multiple games in multiple time periods. Each game is supported separately by different companies while serving under the same Battalion so that all games and soldiers function individually and as all whole."/>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link rel="stylesheet" type="text/css" href="assets/css/styles.css">
		<link rel="stylesheet" type="text/css" href="assets/css/animate.css">
		<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900&display=swap" rel="stylesheet">
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
		<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
		<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<script src="assets/js/pace.js"></script>
	</head>
	<body>
		<?php require('header.php') ?>
		<div id="enlist" class="d-none d-sm-none d-md-block d-lg-block d-xl-block">
			<div id="enlist_top">
			</div>
			<div id="enlist_bottom">
				<div id="enlist_one">
					<p id="enlist_header">Enlist</p>
					<p id="enlist_text">Welcome to the 29th Infantry Division. We are a realism unit, based on the US military system of ranks, command, and strategy.</p>
					<p id="enlist_text_two">You are here because you wish to enlist in the 29th Infantry Division. We are looking for dedicated, mature soldiers willing to put time and effort into bettering their skills and strategy for the unit.</p>
					<p id="enlist_text_two">Those wishing to enlist with the 29th Infantry Division must first understand the following:</p>
					<p id="enlist_text_list">&#9675; <b>We do not care about your in-game skill</b> <br>
		Our Basic Training program will teach you all the skills you need to know to get by in a realism scrimmage. After Basic Training, our AIT program will teach you enough about your weapon to make you much better at the game. Some of the worst players in Darkest Hour have turned into some of the best riflemen after two or three weeks in the 29th.</p>
					<p id="enlist_text_list">&#9675; <b>You might get yelled at</b> <br>
		This is just a game, but we provide a realistic experience for everyone that turns out quite enjoyable. If in Basic Training you are wondering why someone is yelling at you, don't take it personally - it's their job. Just turn on Full Metal Jacket and be thankful that <a id="enlistment_links" href="https://www.youtube.com/watch?v=tHxf17yJsKs" target="_blank">Gunnery Sergeant Hartman</a> isn't your Drill Sergeant.</p>
					<p id="enlist_text_list">&#9675; <b>Our schedule is easy</b> <br>
		Some get overwhelmed when they find out the Basic Training schedule - realize that we understand if you cannot attend a day or two, but that we ask you to attend as many as possible. More importantly, after Basic, your schedule is roughly two hours per week -- and you can miss those if something comes up! There are so many different drill times that we can always work something out to fit your schedule.</p>
					<p id="enlist_text_list">&#9675; <b>We focus on one weapon at a time</b> <br>
		All of our soldiers are trained with their specialty weapon. As we are an Infantry Battalion, most of our members are Riflemen - and very good ones. Each cadet starts out using only rifles to develop a solid rifleman foundation. After Basic Training, you can be placed in training for a different weapon or stick with rifle training.</p>
					<hr id="quote_divider">
					<div class="slideshow-container">
						<p id="quote_header">Quotes from our Personnel</p>
						<div class="quotes animated zoomIn">
						  <q>In terms of realism - which is appealing in 29th. I like the structures of it. Starting from Private and doing all dirty job, then becoming an NCO trying to keep your men together and finally planning things as an officer. It makes me feel like I'm in real unit. Like Band of Brothers. There is no same kind of personality, no same way we do stuff. When you look at the stripes on your shoulders and brass on your chest, pinned to your jacket. You will say: 'That was so exciting to get it.' and that's what I like about 29th.</q>
						  <p class="author">- T/4 Stachurski</p>
						</div>
						<div class="quotes hidden animated zoomIn">
						  <q>The 29th isn't just a realism unit, it feels like a family or a home away from home where you meet some awesome friends and make awesome memories that you can tell to future privates.</q>
						  <p class="author">- PFC Guyette</p>
						</div>
						<div class="quotes hidden animated zoomIn">
						  <q>When I first join the 29th and attended BCT I was somewhat nervous. I didn't think I would pass and have to move on and find another group, to my surprised I did and haven't looked back. When I first got assigned to my squad I was blown away at the helpful and friendly nature of everyone and as I continue my 29th career of being a DI I look forward seeing new recruits like myself and wondering what they'll achieve within the 29th.</q>
						  <p class="author">- PFC Wright</p>
						</div>
						<div class="quotes hidden animated zoomIn">
						  <q>The 29th is not only a great MILSIM unit that has shown me how immersive video games can be, but also a place where I have met members who became real-life friends. In the last two years i had an awesome experience, and witnessing how Easy Company keeps advancing is definitely worth every minute.</q>
						  <p class="author">- Cpl. Kardell</p>
						</div>
						<div class="quotes hidden animated zoomIn">
						  <q>When I joined the 29th I was really scared because I was never the one to talk online and it was the first unit I was trying to join. Fast forward 3 years and I don't think I have ever made a better decision. I have met some of the best people during my time here, both just chatting online, playing games and in real life. Friendships made here go far beyond just an online thing, you become really close to people and that's something I never thought I'd experience when I signed the enlistment papers.</q>
						  <p class="author">- Cpl. Baron</p>
						</div>
						<div class="quotes hidden animated zoomIn">
						  <q>The 29th, to me, is best known for our community and the friendships established along the way. I have met people in this unit that I will cherish and remember for my entire life. I play dozens of various games with them and I have a wonderful time. If you wish to join a community saturated with entertaining and delightful people, then enlist into the 29th.</q>
						  <p class="author">- Cpl. Deb</p>
						</div>
						<div class="quotes hidden animated zoomIn">
						  <q>Since being in the 29th i can say that it is not only a mil-sim community, but an online community like no other I've seen. I can attribute that to much of the history behind the unit and the standards they put forwards for themselves not only in maintaining in-game skills but the friendships that blossom from all that time spent in-game. The size and breadth of the community draws people from across the globe, it has been a lot of fun to be able to play with these gentlemen (and ladies). They take the time to train and compete within and outside of the unit. I've had a great many hours of fun with them and I look to a great many more.</q>
						  <p class="author">- T/5 Perez-Pantoja</p>
						</div>
						<div class="quotes hidden animated zoomIn">
						  <q>There is no other unit, community or online organization quite like the 29th. It is something truly unique in the world of online gaming. We train and fight with the singular goal of achieving victory, but we do so through a combination of teamwork, skill and strategy. You don't have to be best shot in the world. If you are willing to show up, follow orders and be a team player then you absolutely have a place here.</q>
						  <p class="author">- TSgt. Dethfield</p>
						</div>
						<div class="quotes hidden animated zoomIn">
						  <q>It's not every day that you find a gaming organization that has been thriving for a decade and a half with no signs of slowing down. The 29th is more than just a bunch of gamers pretending to be in the military. Ask anyone who has spent any significant amount of time among our ranks and they will tell you how they have been able to use the skills they learned in our unit in their real lives. I've been here for nearly 13 years and can say without a doubt that I've never regretted a second in the 29th ID and what I've learned has truly changed my life. Say hello to your new family away from home.</q>
						  <p class="author">- MSgt. Conrad</p>
						</div>
						<a class="prev" onclick="plusSlides(-1)">&#10094;</a>
						<a class="next" onclick="plusSlides(1)">&#10095;</a>
					</div>
					<div class="dot-container">
					  <span class="dot active" onclick="currentSlide(1)"></span>
					  <span class="dot" onclick="currentSlide(2)"></span>
					  <span class="dot" onclick="currentSlide(3)"></span>
					  <span class="dot" onclick="currentSlide(4)"></span>
					  <span class="dot" onclick="currentSlide(5)"></span>
					  <span class="dot" onclick="currentSlide(6)"></span>
					  <span class="dot" onclick="currentSlide(7)"></span>
					  <span class="dot" onclick="currentSlide(8)"></span>
					  <span class="dot" onclick="currentSlide(9)"></span>
					</div>
					<hr id="quote_divide_two">
					<p id="enlist_button_page"><a id="enlist_button_page_link" onclick="document.getElementById('enlist_one').style.display = 'none'; document.getElementById('enlist_two').style.display = 'block'; $(window).scrollTop(0);">Enlist</a></p>
				</div>
				<div id="enlist_two">
					<div class="animated flipInX">
						<p id="enlistment_two_header">Enlistment Process</p>
						<p id="enlist_text">IMPORTANT! If you have enlisted with us before 2015, please follow these instructions at <a id="enlistment_links" href="http://forums.29th.org/discussion/28/migration-instructions" target="_blank"><i><u>Migration Instructions</u></i></a> first.</p>
						<p id="enlist_text_two">Here's how enlisting works:</p>
						<p id="enlist_text_list">&#9675; <b>Step 1.</b> Create an account on <a id="enlistment_links" href="http://forums.29th.org/entry/register" target="_blank"><i><u>our forums</u></i></a></p>
						<p id="enlist_text_list">&#9675; <b>Step 2.</b> Confirm your email address by clicking the link in the registration email</p>
						<p id="enlist_text_list">&#9675; <b>Step 3.</b> While logged in, fill out an <a id="enlistment_links" href="http://personnel.29th.org/#enlist" target="_blank"><i><u>enlistment form</u></i></a></p>
						<p id="enlist_text_list">&#9675; <b>Step 4.</b> Bookmark the page you're taken to when it's posted and check back tomorrow for a response</p>
					</div>
				</div>
			</div>
		</div>
		<div id="enlist_small" class="d-block d-sm-block d-md-none d-lg-none d-xl-none">
			<div id="enlist_top">
			</div>
			<div id="enlist_bottom">
				<div id="enlist_one_small">
					<p id="enlist_header_small">Enlist</p>
					<p id="enlist_text">Welcome to the 29th Infantry Division. We are a realism unit, based on the US military system of ranks, command, and strategy.</p>
					<p id="enlist_text_two">You are here because you wish to enlist in the 29th Infantry Division. We are looking for dedicated, mature soldiers willing to put time and effort into bettering their skills and strategy for the unit.</p>
					<p id="enlist_text_two">Those wishing to enlist with the 29th Infantry Division must first understand the following:</p>
					<p id="enlist_text_list">&#9675; <b>We do not care about your in-game skill</b> <br>
		Our Basic Training program will teach you all the skills you need to know to get by in a realism scrimmage. After Basic Training, our AIT program will teach you enough about your weapon to make you much better at the game. Some of the worst players in Darkest Hour have turned into some of the best riflemen after two or three weeks in the 29th.</p>
					<p id="enlist_text_list">&#9675; <b>You might get yelled at</b> <br>
		This is just a game, but we provide a realistic experience for everyone that turns out quite enjoyable. If in Basic Training you are wondering why someone is yelling at you, don't take it personally - it's their job. Just turn on Full Metal Jacket and be thankful that <a id="enlistment_links" href="https://www.youtube.com/watch?v=tHxf17yJsKs" target="_blank">Gunnery Sergeant Hartman</a> isn't your Drill Sergeant.</p>
					<p id="enlist_text_list">&#9675; <b>Our schedule is easy</b> <br>
		Some get overwhelmed when they find out the Basic Training schedule - realize that we understand if you cannot attend a day or two, but that we ask you to attend as many as possible. More importantly, after Basic, your schedule is roughly two hours per week -- and you can miss those if something comes up! There are so many different drill times that we can always work something out to fit your schedule.</p>
					<p id="enlist_text_list">&#9675; <b>We focus on one weapon at a time</b> <br>
		All of our soldiers are trained with their specialty weapon. As we are an Infantry Battalion, most of our members are Riflemen - and very good ones. Each cadet starts out using only rifles to develop a solid rifleman foundation. After Basic Training, you can be placed in training for a different weapon or stick with rifle training.</p>
					<hr id="quote_divider">
					<div class="slideshow-container">
						<p id="quote_header">Quotes from our Personnel</p>
						<div class="quotes_small animated zoomIn">
						  <q>In terms of realism - which is appealing in 29th. I like the structures of it. Starting from Private and doing all dirty job, then becoming an NCO trying to keep your men together and finally planning things as an officer. It makes me feel like I'm in real unit. Like Band of Brothers. There is no same kind of personality, no same way we do stuff. When you look at the stripes on your shoulders and brass on your chest, pinned to your jacket. You will say: 'That was so exciting to get it.' and that's what I like about 29th.</q>
						  <p class="author">- T/4 Stachurski</p>
						</div>
						<div class="quotes_small hidden animated zoomIn">
						  <q>The 29th isn't just a realism unit, it feels like a family or a home away from home where you meet some awesome friends and make awesome memories that you can tell to future privates.</q>
						  <p class="author">- PFC Guyette</p>
						</div>
						<div class="quotes_small hidden animated zoomIn">
						  <q>When I first join the 29th and attended BCT I was somewhat nervous. I didn't think I would pass and have to move on and find another group, to my surprised I did and haven't looked back. When I first got assigned to my squad I was blown away at the helpful and friendly nature of everyone and as I continue my 29th career of being a DI I look forward seeing new recruits like myself and wondering what they'll achieve within the 29th.</q>
						  <p class="author">- PFC Wright</p>
						</div>
						<div class="quotes_small hidden animated zoomIn">
						  <q>The 29th is not only a great MILSIM unit that has shown me how immersive video games can be, but also a place where I have met members who became real-life friends. In the last two years i had an awesome experience, and witnessing how Easy Company keeps advancing is definitely worth every minute.</q>
						  <p class="author">- Cpl. Kardell</p>
						</div>
						<div class="quotes_small hidden animated zoomIn">
						  <q>When I joined the 29th I was really scared because I was never the one to talk online and it was the first unit I was trying to join. Fast forward 3 years and I don't think I have ever made a better decision. I have met some of the best people during my time here, both just chatting online, playing games and in real life. Friendships made here go far beyond just an online thing, you become really close to people and that's something I never thought I'd experience when I signed the enlistment papers.</q>
						  <p class="author">- Cpl. Baron</p>
						</div>
						<div class="quotes_small hidden animated zoomIn">
						  <q>The 29th, to me, is best known for our community and the friendships established along the way. I have met people in this unit that I will cherish and remember for my entire life. I play dozens of various games with them and I have a wonderful time. If you wish to join a community saturated with entertaining and delightful people, then enlist into the 29th.</q>
						  <p class="author">- Cpl. Deb</p>
						</div>
						<div class="quotes_small hidden animated zoomIn">
						  <q>Since being in the 29th i can say that it is not only a mil-sim community, but an online community like no other I've seen. I can attribute that to much of the history behind the unit and the standards they put forwards for themselves not only in maintaining in-game skills but the friendships that blossom from all that time spent in-game. The size and breadth of the community draws people from across the globe, it has been a lot of fun to be able to play with these gentlemen (and ladies). They take the time to train and compete within and outside of the unit. I've had a great many hours of fun with them and I look to a great many more.</q>
						  <p class="author">- T/5 Perez-Pantoja</p>
						</div>
						<div class="quotes_small hidden animated zoomIn">
						  <q>There is no other unit, community or online organization quite like the 29th. It is something truly unique in the world of online gaming. We train and fight with the singular goal of achieving victory, but we do so through a combination of teamwork, skill and strategy. You don't have to be best shot in the world. If you are willing to show up, follow orders and be a team player then you absolutely have a place here.</q>
						  <p class="author">- TSgt. Dethfield</p>
						</div>
						<div class="quotes_small hidden animated zoomIn">
						  <q>It's not every day that you find a gaming organization that has been thriving for a decade and a half with no signs of slowing down. The 29th is more than just a bunch of gamers pretending to be in the military. Ask anyone who has spent any significant amount of time among our ranks and they will tell you how they have been able to use the skills they learned in our unit in their real lives. I've been here for nearly 13 years and can say without a doubt that I've never regretted a second in the 29th ID and what I've learned has truly changed my life. Say hello to your new family away from home.</q>
						  <p class="author">- MSgt. Conrad</p>
						</div>
						<a class="prev" onclick="plusSlidesSmall(-1)">&#10094;</a>
						<a class="next" onclick="plusSlidesSmall(1)">&#10095;</a>
					</div>
					<div class="dot-container">
					  <span class="dot_small active" onclick="currentSlideSmall(1)"></span>
					  <span class="dot_small" onclick="currentSlideSmall(2)"></span>
					  <span class="dot_small" onclick="currentSlideSmall(3)"></span>
					  <span class="dot_small" onclick="currentSlideSmall(4)"></span>
					  <span class="dot_small" onclick="currentSlideSmall(5)"></span>
					  <span class="dot_small" onclick="currentSlideSmall(6)"></span>
					  <span class="dot_small" onclick="currentSlideSmall(7)"></span>
					  <span class="dot_small" onclick="currentSlideSmall(8)"></span>
					  <span class="dot_small" onclick="currentSlideSmall(9)"></span>
					</div>
					<hr id="quote_divide_two">
					<p id="enlist_button_page"><a id="enlist_button_page_link" onclick="document.getElementById('enlist_one_small').style.display = 'none'; document.getElementById('enlist_two_small').style.display = 'block'; $(window).scrollTop(0);">Enlist</a></p>
				</div>
				<div id="enlist_two_small">
					<div class="animated flipInX">
						<p id="enlistment_two_header">Enlistment Process</p>
						<p id="enlist_text">IMPORTANT! If you have enlisted with us before 2015, please follow these instructions at <a id="enlistment_links" href="http://forums.29th.org/discussion/28/migration-instructions" target="_blank"><u>Migration Instructions</u></a> first.</p>
						<p id="enlist_text_two">Here's how enlisting works:</p>
						<p id="enlist_text_list">&#9675; <b>Step 1.</b> Create an account on <a id="enlistment_links" href="http://forums.29th.org/entry/register" target="_blank"><i><u>our forums</u></i></a></p>
						<p id="enlist_text_list">&#9675; <b>Step 2.</b> Confirm your email address by clicking the link in the registration email</p>
						<p id="enlist_text_list">&#9675; <b>Step 3.</b> While logged in, fill out an <a id="enlistment_links" href="http://personnel.29th.org/#enlist" target="_blank"><i><u>enlistment form</u></i></a></p>
						<p id="enlist_text_list">&#9675; <b>Step 4.</b> Bookmark the page you're taken to when it's posted and check back tomorrow for a response</p>
					</div>
				</div>
			</div>
		</div>
	</body>
	<?php require('footer.php') ?>
	<script>
		if (navigator.userAgent.toLowerCase().indexOf('firefox') > -1) {
			document.getElementById("enlist_button_four").classList.add("selected_three");
			document.getElementById("enlist_button_five").classList.add("selected_three");
		}
		if (document.documentMode || !/Edge/.test(navigator.userAgent)) {
			function start_nav() {
				document.getElementById("enlist_button").classList.add("selected");
				document.getElementById("enlist_button_two").classList.add("selected");
				document.getElementById("enlist_button_three").classList.add("selected_mobile");
				document.getElementById("enlist_button_dropshadow").classList.add("selected");
				document.getElementById("enlist_button_dropshadow_fix").style.opacity = "1.0";
				document.getElementById("enlist_button_dropshadow_fix_two").style.opacity = "1.0";
			}
			start_nav()
		} else {
			document.getElementById("enlist_header").style.textDecoration = "none";
			document.getElementById("enlist_header").style.color = "rgba(203,209,131,1)";
			document.getElementById("quote_header").style.textDecoration = "none";
			document.getElementById("quote_header").style.color = "rgba(203,209,131,1)";
			document.getElementById("enlist_header_small").style.textDecoration = "none";
			document.getElementById("enlist_header_small").style.color = "rgba(203,209,131,1)";
			document.getElementById("enlist_button_four").classList.add("selected_three");
			document.getElementById("enlist_button_five").classList.add("selected_three");
			document.getElementById("enlist_button_three").classList.add("selected_mobile");
		}
		var slideIndex = 1;
		showSlides(slideIndex);

		function plusSlides(n) {
			showSlides(slideIndex += n);
		}

		function currentSlide(n) {
			showSlides(slideIndex = n);
		}
		function showSlides(n) {
			var i;
			var slides = document.getElementsByClassName("quotes");
			var dots = document.getElementsByClassName("dot");
			if (n > slides.length) {slideIndex = 1}
			if (n < 1) {slideIndex = slides.length}
			for (i = 0; i < slides.length; i++) {
				slides[i].style.display = "none";
			}
			for (i = 0; i < dots.length; i++) {
				dots[i].className = dots[i].className.replace(" active", "");
			}
			slides[slideIndex-1].style.display = "block";
			dots[slideIndex-1].className += " active";
		}
		var slideIndexSmall = 1;
		showSlidesSmall(slideIndexSmall);

		function plusSlidesSmall(n) {
			showSlidesSmall(slideIndexSmall += n);
		}

		function currentSlideSmall(n) {
			showSlidesSmall(slideIndexSmall = n);
		}
		function showSlidesSmall(n) {
			var i;
			var slidesSmall = document.getElementsByClassName("quotes_small");
			var dotsSmall = document.getElementsByClassName("dot_small");
			if (n > slidesSmall.length) {slideIndexSmall = 1}
			if (n < 1) {slideIndexSmall = slidesSmall.length}
			for (i = 0; i < slidesSmall.length; i++) {
				slidesSmall[i].style.display = "none";
			}
			for (i = 0; i < dotsSmall.length; i++) {
				dotsSmall[i].className = dotsSmall[i].className.replace(" active", "");
			}
			slidesSmall[slideIndexSmall-1].style.display = "block";
			dotsSmall[slideIndexSmall-1].className += " active";
		}
	</script>
</html>